#!/usr/bin/env bash
scala -cp . Assignment3.TurtleEDSL.Assignment3Embedded $@
