package Assignment3.TurtleStandalone
import Assignment3.TurtleEDSL.Assignment3Embedded.TurtleDSL
import Assignment3.TurtleEDSL.Assignment3Embedded.Testing
import Assignment3.TurtleEDSL.Assignment3Embedded.TurtleDSLImpl
import Assignment3.GraphicsCanvas._
import java.awt.Color
import java.util.Random
import scala.collection.immutable.Set
import scala.collection.immutable.ListMap

import scala.util.parsing.combinator.PackratParsers
import scala.util.parsing.combinator.syntactical.StandardTokenParsers

object Assignment3Standalone {
  type Variable = String
  type Location = Int
  type Env[A] = Map[Variable,A]
  type Store[A] = Map[Location,A]

  // Arithmetic expressions

  abstract class Expr
  case class Plus(e1: Expr, e2: Expr) extends Expr
  case class Minus(e1: Expr, e2: Expr) extends Expr
  case class Times(e1: Expr, e2: Expr) extends Expr
  case class Div(e1: Expr, e2: Expr) extends Expr

  // Booleans
  case class Eq(e1: Expr, e2:Expr) extends Expr
  case class IfThenElse(e: Expr, e1: Expr, e2: Expr) extends Expr
  case class GreaterThan(e1: Expr, e2: Expr) extends Expr
  case class LessThan(e1: Expr, e2: Expr) extends Expr

  // Variables and let-binding
  case class Var(x: Variable) extends Expr
  case class Let(x: Variable, e1: Expr, e2: Expr) extends Expr
  case class LetFun(f: Variable, arg: Variable, ty: Type, e1:Expr, e2:Expr)
      extends Expr
  case class LetRec(f: Variable, arg: Variable, xty: Type, ty: Type, e1:Expr, e2:Expr)
      extends Expr
  case class LetPair(x: Variable, y: Variable, ePair: Expr, eBody: Expr) extends Expr

  // Pairs
  case class Pair(e1: Expr, e2: Expr) extends Expr
  case class Fst(e: Expr) extends Expr
  case class Snd(e: Expr) extends Expr

  // Functions
  case class Lambda(x: Variable, ty: Type, e: Expr) extends Expr
  case class Rec(f: Variable, x: Variable, tyx:Type, ty: Type, e: Expr) extends Expr
  case class Apply(e1: Expr, e2: Expr) extends Expr

  // e1 ; e2
  case class Sequence(e1: Expr, e2: Expr) extends Expr

  // References
  case class Loc(loc: Location) extends Expr
  case class CreateRef(e: Expr) extends Expr
  case class Deref(e: Expr) extends Expr
  case class Assign(e1: Expr, e2: Expr) extends Expr

  // Lists
  case class EmptyList(ty: Type) extends Expr
  case class Cons(e: Expr, e2: Expr) extends Expr
  case class ListCase(l: Expr, e1: Expr, x: Variable, y: Variable, e2: Expr) extends Expr

  // Turtle-y things
  case class Forward(e: Expr) extends Expr
  case class Backward(e: Expr) extends Expr
  case class Right(e: Expr) extends Expr
  case class Left(e: Expr) extends Expr
  case class PenUp() extends Expr
  case class PenDown() extends Expr
  case class SetCol(e: Expr) extends Expr
  case class RandCol(e: Expr) extends Expr

  // Looping
  case class While(pred: Expr, body: Expr) extends Expr
  case class DoWhile(body: Expr, pred: Expr) extends Expr

  // Case which lifts a value into an expression
  //case class ValueExpr(v: Value) extends Expr

  // Values
  abstract class Value extends Expr
  case object UnitV extends Value
  case class NumV(n: Int) extends Value
  case class BoolV(n: Boolean) extends Value
  case class ColorV(c: Color) extends Value
  case class ListV(l: List[Value]) extends Value
  case class LocV(loc: Location) extends Value
  case class PairV(fst: Value, snd: Value) extends Value
  case class FunV(x: Variable, e: Expr) extends Value
  case class RecV(f: Variable, x: Variable, e: Expr) extends Value


    // Types
  abstract class Type
  case object UnitTy extends Type
  case object IntTy extends Type
  case object BoolTy extends Type
  case object ColorTy extends Type
  case class ListTy(ty1: Type) extends Type
  case class RefTy(ty1: Type) extends Type
  case class PairTy(ty1: Type, ty2: Type) extends Type
  case class FunTy(ty1: Type, ty2: Type) extends Type

  object Gensym {
    private var id = 0
    def gensym(s: Variable): Variable = {
      val fresh_s = s + "_" + id
      id = id + 1
      fresh_s
    }
  }

  object Genloc {
    private var id = 0
    def genloc(): Location = {
      val newloc = id
      id = id + 1
      newloc
    }
  }

  val rand = new Random(System.currentTimeMillis())

  /****************
   *  Exercise 3  *
   ****************/

  // Typechecker
  // typing: calculate the return type of e, or throw an error
  def tyOf(ctx: Env[Type], e: Expr): Type = {
    def valueTy(v: Value): Type = v match {
      case UnitV => UnitTy
      case NumV(_) => IntTy
      case BoolV(_) => BoolTy
      case ColorV(_) => ColorTy
      case ListV(_) => sys.error("Impossible case: ListTy(xs) only introduced at runtime")
      case LocV(_) => sys.error("Impossible case: Locations are only introduced at runtime, and have no type")
      case PairV(_, _) => sys.error("Impossible case: PairV is only introduced at runtime")
      case FunV(_, _) => sys.error("Impossible case: FunV is only introduced at runtime")
      case RecV(_, _, _) => sys.error("Impossible case: FunV is only introduced at runtime")
    }

    e match {
      // Values
      case v: Value => valueTy(v)
      case _ => sys.error("todo")    }
  }


  // Swapping (provided)
  def swapVar(x: Variable, y: Variable, z: Variable): Variable =
    if (x == y) {
      z
    } else if (x == z) {
      y
    } else {
      x
    }

  def swap(e: Expr, y: Variable, z: Variable): Expr = {


    def go(e: Expr): Expr = e match {
      // Values are closed
      case v: Value => v
      case Plus(t1,t2) => Plus(go(t1),go(t2))
      case Minus(t1,t2) => Minus(go(t1),go(t2))
      case Times(t1,t2) => Times(go(t1),go(t2))
      case Div(t1,t2) => Div(go(t1),go(t2))

      case Eq(t1,t2) => Eq(go(t1),go(t2))
      case GreaterThan(t1, t2) => GreaterThan(go(t1), go(t2))
      case LessThan(t1, t2) => LessThan(go(t1), go(t2))
      case IfThenElse(t,t1,t2) => IfThenElse(go(t),go(t1),go(t2))

      case Var(x) => Var(swapVar(x,y,z))
      case Let(x,t1,t2) => Let(swapVar(x,y,z),go(t1),go(t2))
      case LetFun(f,x,ty,t1,t2) => LetFun(swapVar(f,y,z),swapVar(x,y,z),ty,go(t1),go(t2))
      case LetRec(f,x,xty,ty,t1,t2) => LetRec(swapVar(f,y,z),swapVar(x,y,z),xty,ty,go(t1),go(t2))
      case LetPair(x1, x2, t1, t2) =>
        LetPair(swapVar(x1, y, z), swapVar(x2, y, z), go(t1), go(t2))

      case Lambda(x,ty,t) => Lambda(swapVar(x,y,z),ty,go(t))
      case Apply(t1,t2) => Apply(go(t1),go(t2))
      case Rec(f,x,xty,ty,t) => Rec(swapVar(f,y,z), swapVar(x,y,z), xty,ty,go(t))

      case Sequence(t1, t2) => Sequence(go(t1), go(t2))
      // References
      case Loc(l) => Loc(l)
      case CreateRef(t) => CreateRef(go(t))
      case Deref(t) => Deref(go(t))
      case Assign(t1, t2) => Assign(go(t1), go(t2))

      // Pairs
      case Pair(t1, t2) => Pair(go(t1), go(t2))
      case Fst(t) => Fst(go(t))
      case Snd(t) => Snd(go(t))

      // Lists
      case EmptyList(t) => EmptyList(t)
      case Cons(t1, t2) => Cons(go(t1), go(t2))
      case ListCase(l, t1, consVar1, consVar2, t2) =>
        ListCase(go(l), go(t1), swapVar(consVar1, y, z), swapVar(consVar2, y, z), go(t2))

      // Turtle constructs
      case Forward(t) => Forward(go(t))
      case Backward(t) => Backward(go(t))
      case Right(t) => Right(go(t))
      case Left(t) => Left(go(t))
      case SetCol(t) => SetCol(go(t))
      case RandCol(t) => RandCol(go(t))
      case PenUp() => PenUp()
      case PenDown() => PenDown()

      // Looping
      case While(p, b) => While(go(p), go(b))
      case DoWhile(b, p) => DoWhile(go(b), go(p))
    }
    go(e)
  }

  /****************
   *  Exercise 4  *
   ****************/
  def subst(e1:Expr, e2:Expr, x: Variable): Expr = {

    e1 match {
      // Values are closed so substitution has no effect
      case v: Value => v
      case _ => sys.error("todo")
      
    }
  }

  /****************
   *  Exercise 5  *
   ****************/
  // Desugaring
  def desugar(e: Expr): Expr = sys.error("todo")


  class Eval(tg: TurtleDSL) {
    import tg._

    // State used to keep track of canvas, co-ords, angle, pen state
    private final case class TurtleState(
      store: Store[Value],
      graphics: TurtleGraphics
    )

    // Some potentially-useful helper methods
    // Any methods whose types mention TurtleState need to be private
    private def updateVarMapping(locName: Location, v: Value, ts: TurtleState) = {
      val vmap = ts.store
      ts.copy (store = vmap + (locName -> v))
    }

    private def getVarMapping(locName: Location, ts: TurtleState): Value = {
      ts.store(locName)
    }

    private def addGraphics(tg: TurtleGraphics, ts: TurtleState) = {
      val graphics = ts.graphics
      ts.copy (graphics = graphics <> tg)
    }

    private def evalBinArgs(st: TurtleState, e1: Expr, e2: Expr): (TurtleState, Value, Value) = {
      val (st1, v1) = eval(st, e1)
      val (st2, v2) = eval(st1, e2)
      (st2, v1, v2)
    }

    /****************
     *  Exercise 6  *
     ****************/

    private def eval(state: TurtleState, expr: Expr): (TurtleState, Value) = expr match { 
      case v: Value => (state,v)
      case _ => sys.error("todo")
    }

    def evalExpr(expr: Expr): Value = {
      val initState = TurtleState(ListMap(),empty)
      val (_endState, endResult) = eval(initState, expr)
      endResult
    }

    // Interpreter
    def run(expr: Expr, width: Integer, height: Integer): GraphicsCanvas = {
      val initState = TurtleState(ListMap(),empty)
      val (endState,_endResult) = eval(initState, expr)
      return draw(endState.graphics,width,height)
    }
  }



  /////////////////// BEGIN SUPPORT CODE
  ///////////////////
  // You should not change anything below this comment
  ///////////////////
  // Parser

  class CWParser extends StandardTokenParsers with PackratParsers {

    type P[+A] = PackratParser[A]

    def parseStr(input: String): Expr = {
      phrase(expression)(new lexical.Scanner(input)) match {
        case Success(ast, _) => ast
        case e: NoSuccess => sys.error(e.msg)
      }
    }

    def parse(input: String): Expr = {
      val source = scala.io.Source.fromFile(input)
      val lines = try source.mkString finally source.close()
      parseStr(lines)
    }

    lexical.reserved += ("let", "in", "rec", "if", "then", "else",
      "int","bool","true","false","fun","color",
      "Red","Green", "Blue", "Pink","Black", "forward", "backward", "right","left","penUp",
      "penDown","setCol","randCol","ref", "case", "list", "ref", "while", "do",
      "fst", "snd", "unit"
    )
    lexical.delimiters += ("=","*", "\\", "+", "-", "(", ")", "==", ":", ":=", ".",
      "->", "=>", "{", "}", "|", "::", "[", "]", "|->", ">", "<", "!", "()", ";", "/", ","
    )


    // Order of precedence (loosest binding first)
    // ;
    // :=, ::
    // <, ==, >
    // +, -
    // *
    // !
    lazy val binaryOp: P[Expr] = {
      sequence
    }

    lazy val sequence: P[Expr] = {
      expression~";"~expression ^^ {
        case e1~";"~e2 => Sequence(e1, e2)
      } | assignOrCons
    }

    lazy val assignOrCons: P[Expr] = {
      ((expression <~ ":=") ~ binRel) ^^ {
        case e1~e2 => Assign(e1, e2)
      } | ((expression <~ "::") ~ expression) ^^ {
        case e1~e2 => Cons(e1, e2)
      } | binRel
    }

    lazy val binRel: P[Expr] =
      expression ~ "==" ~ summation ^^ {
        case e1~"=="~e2 => Eq(e1,e2)
      } | expression ~ "<" ~ summation ^^ {
        case e1~"<"~e2 => LessThan(e1,e2)
      } | expression ~ ">" ~ summation ^^ {
        case e1~">"~e2 => GreaterThan(e1,e2)
      } | summation

    lazy val summation: P[Expr] =
      summation ~ "+" ~ prod ^^ {
        case e1~"+"~e2 => Plus(e1,e2)
      } | summation ~ "-" ~ prod ^^ {
        case e1~"-"~e2 => Minus(e1,e2)
      } | prod

    lazy val prod: P[Expr] =
      prod ~ "*" ~ unaryOp ^^ {
        case e1~"*"~e2 => Times(e1,e2)
      } | prod ~ "/" ~ unaryOp ^^ {
        case e1~"/"~e2 => Div (e1,e2)
      } | unaryOp

    lazy val pRed: P[Expr] = "Red" ^^^ ColorV(Color.RED)

    lazy val pGreen: P[Expr] = "Green" ^^^ ColorV(Color.GREEN)
    lazy val pBlue: P[Expr] = "Blue" ^^^ ColorV(Color.BLUE)
    lazy val pPink: P[Expr] = "Pink" ^^^ ColorV(Color.PINK)
    lazy val pBlack: P[Expr] = "Black" ^^^ ColorV(Color.BLACK)
    lazy val colour: P[Expr] =
      pRed | pGreen | pBlue | pPink | pBlack

    lazy val whileLoop: P[Expr] =
      ("while" ~ "(") ~>
      expression~
      ((")" ~ "{") ~> expression) <~ "}" ^^ {
      case pred~body => While(pred, body)
    }

    lazy val doWhileLoop: P[Expr] =
      "do" ~> ("{" ~> expression <~ "}") ~ ("while" ~> "(" ~> expression <~ ")") ^^ {
      case body~pred => DoWhile(body, pred)
    }

    lazy val lambda: P[Expr] =
      ("\\" ~> ident) ~ (":" ~> typ) ~ ("." ~> expression) ^^ {
        case arg~ty~body => Lambda(arg,ty,body)
      }

    lazy val rec: P[Expr] =
      ("rec" ~> ident) ~
        ("(" ~> ident) ~ (":" ~> typ) ~ ((")" ~ ":") ~> typ) ~
        ("." ~> expression) ^^ {
          case recArg~funArg~funType~recType~body =>
            Rec(recArg,funArg,funType,recType,body)
        }

    lazy val ifExpr: P[Expr] =
      ("if" ~> expression) ~
        ("then" ~> expression) ~
        ("else" ~> expression) ^^ {
          case cond~e1~e2 => IfThenElse(cond,e1,e2)
        }

    lazy val letExpr: P[Expr] =
      ("let" ~> ident) ~ ("=" ~> expression) ~ ("in" ~> expression) ^^ {
        case binder~e1~e2 => Let(binder,e1,e2)
      }

    lazy val letFun: P[Expr] =
      ("let" ~ "fun" ~> ident) ~ ("(" ~> ident) ~
        (":" ~> typ <~ ")") ~ ("=" ~> expression) ~
        ("in" ~> expression) ^^ {
          case fun~binder~ty~e1~e2 => LetFun(fun,binder,ty,e1,e2)
        }

    lazy val letRec: P[Expr] = {
      ("let" ~ "rec" ~> ident) ~ ("(" ~> ident) ~
        (":" ~> typ <~ ")") ~ (":" ~> typ) ~ ("=" ~> expression) ~
        ("in" ~> expression ) ^^ {
          case fun~binder~xty~ty~e1~e2 => LetRec(fun,binder,xty,ty,e1,e2)
        }
      }

    lazy val letPair: P[Expr] =
      ("let" ~ "(") ~> ident ~ ("," ~> ident <~ ")") ~
        ("=" ~> expression) ~ ("in" ~> expression) ^^ {
          case x~y~e1~e2 => LetPair(x,y,e1,e2)
        }

    lazy val emptyList: P[Expr] =
      (("[" ~ "]") ~> ":" ~> typ) ^^ EmptyList

    lazy val emptyListCase: P[Expr] =
      ((("[" ~ "]") ~ "|->") ~> expression)

    lazy val consListCase: P[(Variable, Variable, Expr)] = {
      (ident<~"::")~(ident <~ "|->")~expression ^^ {
        case i1~i2~e => (i1, i2, e)
      }
    }

    lazy val listCase: P[Expr] = {
        (("case"~> expression <~"{")~
          emptyListCase~("|" ~> consListCase <~ "}")) ^^ {
           case scrutinee~ec~cc =>
            cc match {
              case (i1, i2, cc) => ListCase(scrutinee, ec, i1, i2, cc)
            }
        }
    }

    lazy val unaryOp: P[Expr] =
      createRef | deref | fact

    lazy val createRef: P[Expr] =
      ("ref"~>fact) ^^ CreateRef

    lazy val deref: P[Expr] =
      ("!"~>fact) ^^ Deref

    lazy val typ: P[Type] =
      funTyp

    lazy val funTyp: P[Type] =
      typ ~ "->" ~ funTyp ^^ {
        case t1~"->"~t2 => FunTy(t1,t2)
      } | pairTyp

    lazy val pairTyp: P[Type] =
      primitiveType ~ "*" ~ pairTyp ^^ {
        case t1~"*"~t2 => PairTy(t1,t2)
      } | listTyp

    lazy val listTyp: P[Type] =
      "list" ~> ("[" ~> typ <~ "]") ^^ {
      case innerTy => ListTy(innerTy)
    } | refTyp

    lazy val refTyp: P[Type] =
      "ref" ~> ("[" ~> typ <~ "]") ^^ {
      case innerTy => RefTy(innerTy)
    } | primitiveType

    lazy val primitiveType: P[Type] =
      "bool" ^^^ BoolTy | "int" ^^^ IntTy | "color" ^^^ ColorTy |
      "unit" ^^^ UnitTy | "("~>typ<~")"

    lazy val application: P[Expr] = {
      fact ~ fact ^^ {
        case e1~e2 => Apply(e1,e2)
      }
    }

    lazy val forward: P[Expr] =
      ("forward" ~> fact) ^^ {
        case e => Forward(e)
      }

    lazy val backward: P[Expr] =
      ("backward" ~> fact) ^^ {
        case e => Backward(e)
      }

    lazy val right: P[Expr] =
      ("right" ~> fact) ^^ {
        case e => Right(e)
      }

    lazy val left: P[Expr] =
      ("left" ~> fact) ^^ {
        case e => Left(e)
      }

    lazy val setCol: P[Expr] =
      ("setCol" ~> fact) ^^ {
        case e => SetCol(e)
      }

    lazy val randCol: P[Expr] =
      ("randCol" ~> fact) ^^ {
        case e => RandCol(e)
      }

    lazy val penUp: P[Expr] = "penUp" ^^^ PenUp()
    lazy val penDown: P[Expr] = "penDown" ^^^ PenDown()

    lazy val turtleConst: P[Expr] =
      penUp |
      penDown |
      setCol |
      randCol |
      forward |
      backward |
      right |
      left

    lazy val expression: P[Expr] = simpleExpr

    lazy val simpleExpr: P[Expr] = (
        lambda |
        rec |
        letExpr |
        letFun |
        letRec |
        letPair |
        ifExpr |
        binaryOp |
        listCase |
        whileLoop |
        doWhileLoop |
        emptyList |
        fact
    )

    lazy val pairLit: P[Expr] =
      "(" ~> expression ~ "," ~ expression <~ ")" ^^ {
        case t1~","~t2 => Pair(t1,t2)
      }

    lazy val pairOp: P[Expr] =
      ("fst" ~ "(") ~> expression <~ ")" ^^ (x => Fst(x)) |
        ("snd" ~ "(") ~> expression <~ ")" ^^ (x => Snd(x))

    lazy val operations: P[Expr] = (
      application |
      pairOp |
      turtleConst
    )

    lazy val fact: P[Expr] = (
        operations |
        pairLit |
        colour |
        (ident ^^ Var) |
        (numericLit ^^ { x => NumV(x.toInt) }) |
        ("()" ^^^ (UnitV)) |
        ("true" ^^^ BoolV(true)) |
        ("false" ^^^ BoolV(false)) |
        "("~>expression<~")"
    )
  }


  val parser = new CWParser
  object Main {
    def typecheck(ast: Expr):Type =
      tyOf(Map.empty,ast);

    def createCanvasAndRun(w: Integer, h: Integer,
        ast: Expr, outputFilename: String, test: Boolean) = {
      if(test) {
        println("Rendering using Testing...")
        val canvas = new Eval(Testing).run(ast, w, h)
        canvas.saveToFile(outputFilename)
      } else {
        println("Rendering using TurtleDSLImpl...")
        val canvas = new Eval(TurtleDSLImpl).run(ast, w, h)
        canvas.saveToFile(outputFilename)
      }
    }

    def showResult(ast: Expr, width: Integer, height: Integer, outputFilename: String, test: Boolean) {
      println("AST:  " + ast.toString + "\n")
      try {
        print("Type Checking...");
        val ty = typecheck(ast);
        println("Done!");
        println("Type of Expression: " + ty.toString + "\n") ;
      } catch {
          case e:Throwable => println("Error: " + e)
      } 
      try{
        println("Desugaring...");
        val core_ast = desugar(ast);
        println("Done!");
        println("Desugared AST: " + core_ast.toString + "\n") ;
        try {
          println("Evaluating...");
          createCanvasAndRun(width, height, core_ast, outputFilename,test)
        } catch {
          case e:Throwable => println("Error: " + e)
        }
      } catch {
        case e: Throwable =>  println("Error: " + e)
          println("Evaluating original AST...");
          createCanvasAndRun(width, height, ast, outputFilename,test)
      }
   
    }
  }

  val FILENAME = "filename"
  val OUTPUT = "output"
  val WIDTH = "width"
  val HEIGHT = "height"
  val TEST = "test"

  val defaultArgs = ListMap (
    FILENAME -> "",
    WIDTH -> "2000",
    HEIGHT -> "2000",
    OUTPUT -> "output.png",
    TEST -> "false"
  )

  def main( args:Array[String] ):Unit = {
    val argList = args.toList

    def readArgs(argList: List[String], optMap: ListMap[String, String]):
      ListMap[String, String] = argList match {
        case Nil => optMap
        case "-o" :: outputName :: tail =>
          readArgs(tail, optMap + (OUTPUT -> outputName))
        case "-w" :: w :: tail =>
          readArgs(tail, optMap + (WIDTH -> w))
        case "-h" :: h :: tail =>
          readArgs(tail, optMap + (HEIGHT -> h))
        case "-t" :: tail =>
          readArgs(tail, optMap + (TEST -> "true"))
        case fn :: _ => optMap + (FILENAME -> fn)
    }

    if (args.length == 0) {
      print("Usage: [-o output_filename] [-w width] [-h height] [-t] filename\n")
    } else {
      print("Parsing...");
      val argMap = readArgs(args.toList, defaultArgs)
      val ast = parser.parse(argMap(FILENAME))
      println("Done!");
      Main.showResult(ast, argMap(WIDTH).toInt, argMap(HEIGHT).toInt, argMap(OUTPUT), argMap(TEST).toBoolean)
    }
  }
}
// vim: set ts=2 sw=2 et sts=2:
