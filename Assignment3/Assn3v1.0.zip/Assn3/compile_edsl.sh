#!/usr/bin/env bash
scalac GraphicsCanvas.scala
scalac TurtleEDSL.scala
