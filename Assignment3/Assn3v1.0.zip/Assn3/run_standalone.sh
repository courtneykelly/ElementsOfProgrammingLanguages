#!/usr/bin/env bash
scala -cp ".:TurtleEDSL.jar" Assignment3.TurtleStandalone.Assignment3Standalone $@
