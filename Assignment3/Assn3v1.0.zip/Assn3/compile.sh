#!/usr/bin/env bash
scalac *.scala
